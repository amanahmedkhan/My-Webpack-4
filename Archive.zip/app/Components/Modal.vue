<template>
	<h1>{{ message }}</h1>
</template>

<script>
	export default {
	  	name:'app',
	  	data(){
	    	return {
	      		message: 'Welcome, This is my new Webpack 4 :)'
	    	};
	  	}
	};
</script>